USE BDI
GO

-- Please Adjust the value for sys param (SHOW TRANSFER Button)
SELECT * FROM tbl_sys_param WHERE function_cd = 12 and cd = 704

--Loan Product
SELECT * FROM tbl_prod WHERE cd in (
'LN_N801',
'LN_N802',
'LN_N805',
'LN_N808',
'LN_N809',
'LN_N811',
'LN_N812',
'LN_N813',
'LN_N850',
'LN_N851',
'LN_N852',
'LN_N853',
'LN_N861',
'LN_N863',
'LN_N864',
'LN_N932',
'LN_N933',
'LN_N934',
'LN_N935',
'LN_N936',
'LN_N955',
'LN_N956',
'LN_N957',
'LN_N958',
'LN_N959',
'LN_N971',
'LN_N972',
'LN_N975',
'LN_N976',
'LN_N977'
) ORDER BY cd

