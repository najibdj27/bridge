select * from bdi.dbo.tbl_res_notification_template with(nolock)
where [language] ='id' and notification_id in ('07E3705B-30F5-40FC-8B91-967FC2E4FDF3', '1B67C6F7-BAF6-4617-A53D-311A3291C674');

select * from bdi.dbo.tbl_notification_channel_template with(nolock)
where id in ('1B67C6F7-BAF6-4617-A53D-311A3291C674','07E3705B-30F5-40FC-8B91-967FC2E4FDF3');