select * into bdi.dbo.tbl_res_notification_template_ccb07juni24
from 
 bdi.dbo.tbl_res_notification_template
 where 
 notification_id in ('07E3705B-30F5-40FC-8B91-967FC2E4FDF3','1B67C6F7-BAF6-4617-A53D-311A3291C674');

select * into bdi.dbo.tbl_notification_channel_template_ccb07juni24
from 
  bdi.dbo.tbl_notification_channel_template
 where 
 id in ('1B67C6F7-BAF6-4617-A53D-311A3291C674','07E3705B-30F5-40FC-8B91-967FC2E4FDF3');