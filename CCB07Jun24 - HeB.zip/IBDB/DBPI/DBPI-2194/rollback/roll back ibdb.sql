UPDATE BDI.dbo.tbl_notification_channel_template SET channel_type=1, dscp=N'Cardless Withdrawal Reservation via Other Bank''s ATM (Success)', template=N'Dear Valued Customer,

[TC24015_01_01]
{__child_trx_hist_det}

Reservation Date : [reservation_date]

Reference No.    : [ref_no]

From             : [source_account]

Handphone No.    : [handphone_number]

Amount           : [amount]

Admin Fee        : [fee]

Token Number     : [token_number]

Token Validity   : [token_validity]

For cardless withdrawal, please visit the nearest Bank CIMB Niaga''s ATM or Bank Multiarta Sentosa’s ATM.

{/__child_trx_hist_det}
[TC24015_01_99]', subject=N'Successful Cardless Withdrawal Reservation via Other Bank''s ATM Notification', template_cd=N'TC24015_01', expression_id=NULL, notification_id=N'358C74FD-36CC-4E4E-B03D-A60A2D95C377', version=N'1B67C6F7-BAF6-4617-A53D-311A3291C674' WHERE id=N'1B67C6F7-BAF6-4617-A53D-311A3291C674';
UPDATE BDI.dbo.tbl_notification_channel_template SET channel_type=2, dscp=N'Cardless Withdrawal Reservation via Other Bank''s ATM (Success)', template=N'Dear Valued Customer,

[TC24015_01_01]
{__child_trx_hist_det}

Reservation Date : [reservation_date]

Reference No.    : [ref_no]

From             : [source_account]

Handphone No.    : [handphone_number]

Amount           : [amount]

Admin Fee        : [fee]

Token Number     : [token_number]

Token Validity   : [token_validity]

For cardless withdrawal, please visit the nearest Bank CIMB Niaga''s ATM or Bank Multiarta Sentosa’s ATM.

{/__child_trx_hist_det}
[TC24015_01_99]', subject=N'Successful Cardless Withdrawal Reservation via Other Bank''s Notification', template_cd=N'TC24015_01', expression_id=NULL, notification_id=N'358C74FD-36CC-4E4E-B03D-A60A2D95C377', version=N'07E3705B-30F5-40FC-8B91-967FC2E4FDF3' WHERE id=N'07E3705B-30F5-40FC-8B91-967FC2E4FDF3';


UPDATE BDI.dbo.tbl_res_notification_template SET notification_id=N'07E3705B-30F5-40FC-8B91-967FC2E4FDF3', [language]=N'id', dscp=N'Cardless Withdrawal Reservation via Other Bank''s ATM (Success)', template=N'Nasabah Yang Terhormat, 

[TC24015_01_05]
{__child_trx_hist_det}

Tanggal Reservasi         : [reservation_date]

No. Referensi             : [ref_no]

Sumber Rekening           : [source_account]

Handphone No.             : [handphone_number]

Jumlah                    : [amount]

Biaya Admin               : [fee]

No. Token                 : [token_number]

Masa Berlaku Token        : [token_validity]

Untuk penarikan tunai tanpa kartu, silakan kunjungi ATM Bank CIMB Niaga atau ATM Bank Multiarta Sentosa.

{/__child_trx_hist_det}
[TC24015_01_98]', subject=N'Notifikasi Reservasi Tarik Tunai Tanpa Kartu Melalui ATM Bank Lain Berhasil (Tidak Perlu Dibalas)';
UPDATE BDI.dbo.tbl_res_notification_template SET notification_id=N'1B67C6F7-BAF6-4617-A53D-311A3291C674', [language]=N'id', dscp=N'Cardless Withdrawal Reservation via Other Bank''s ATM (Success)', template=N'Nasabah Yang Terhormat, 

[TC24015_01_05]
{__child_trx_hist_det}

Tanggal Reservasi         : [reservation_date]

No. Referensi             : [ref_no]

Sumber Rekening           : [source_account]

Handphone No.             : [handphone_number]

Jumlah                    : [amount]

Biaya Admin               : [fee]

No. Token                 : [token_number]

Masa Berlaku Token        : [token_validity]

Untuk penarikan tunai tanpa kartu, silakan kunjungi ATM Bank CIMB Niaga atau ATM Bank Multiarta Sentosa.

{/__child_trx_hist_det}
[TC24015_01_98]', subject=N'Notifikasi Reservasi Tarik Tunai Tanpa Kartu Melalui ATM Bank Lain Berhasil';
