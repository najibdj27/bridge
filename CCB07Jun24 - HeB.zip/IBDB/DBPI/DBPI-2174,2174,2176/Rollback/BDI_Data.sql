USE BDI
GO

DELETE FROM tbl_res_log_template WHERE field_nm IN (
'Coverage Period','Program(s)','Billing Code'
)

DELETE FROM tbl_audit_template WHERE module_id = 217 AND function_id = 40

INSERT INTO tbl_audit_template VALUES
(N'CAC964FC-7B5B-40F5-A742-39AADAE839CD', N'112174001', N'0:user_id;0:login_id;0:ip_addr;0:ref_no;0:dscp;0:amt;0:ccy;0:source;0:destination;0:status;0:reason', 
N'1:inbound/inbound;1:outbound/outbound;
1:ref_no/Reference_No.;
1:trans_date/Transaction_Date;
1:acct_num/Source_Account;
1:org_name/Organization;
1:cust_id/Customer_ID;
1:bill_ref/Bill_Reference;
1:cust_name/Customer_Name;
1:bill_period/Billing_period;
1:bill_amount/Bill_Amount;
1:admin_fee/Admin_Fee;
1:total/Bill_Total;
1:start_dt/Effective_Date;
1:end_dt/Finish_Date;
1:br_office/Branch_Office', 11, 217, 40, 1, 1, 0, 1, 0, 0, N'Successful Payment Insurance (BPJSTK)', NULL, NULL);

INSERT INTO tbl_audit_template VALUES
(N'318CB2F2-DC07-4B2B-B04D-4961011D201D', N'112174002', N'0:user_id;0:login_id;0:ip_addr;0:ref_no;0:dscp;0:amt;0:ccy;0:source;0:destination;0:status;0:reason', 
N'1:inbound/inbound;1:outbound/outbound;
1:ref_no/Reference_No.;
1:trans_date/Transaction_Date;
1:acct_num/Source_Account;
1:org_name/Organization;
1:cust_id/Customer_ID;
1:bill_ref/Bill_Reference;
1:cust_name/Customer_Name;
1:bill_period/Billing_period;
1:bill_amount/Bill_Amount;
1:admin_fee/Admin_Fee;
1:total/Bill_Total;
1:start_dt/Effective_Date;
1:end_dt/Finish_Date;
1:br_office/Branch_Office', 11, 217, 40, 1, 1, 0, 1, 0, 0, N'Unsuccessful Payment Insurance (BPJSTK)', NULL, NULL);


----Email
DELETE FROM tbl_res_notification_template WHERE notification_id IN (
'2D0F7CF4-710C-453F-9533-B8EF1ABB9184',
'3625E409-531D-4B9E-9138-BD5CB735BF26',
'C553619A-D481-4233-9855-BCE46A1ABFBD',
'48D2822D-EB08-4FD0-BCE7-191EC2F521C7'
)
DELETE FROM tbl_notification_channel_template WHERE id IN (
'2D0F7CF4-710C-453F-9533-B8EF1ABB9184',
'3625E409-531D-4B9E-9138-BD5CB735BF26',
'C553619A-D481-4233-9855-BCE46A1ABFBD',
'48D2822D-EB08-4FD0-BCE7-191EC2F521C7'
)

---En
--Success
INSERT INTO tbl_notification_channel_template VALUES(N'2D0F7CF4-710C-453F-9533-B8EF1ABB9184', 1, N'Successful Insurance Payment', 
N'Dear Valued Customer,

Thank you for using D-Bank PRO. We are pleased to inform you that your payment has been successful.

{__child_trx_hist_det}
Transaction Date: [trans_date]

Reference No.: [ref_no]

Source Account: [acct_num]

Payment: Insurance

Organization : [org_name]

Customer ID: [cust_id]

Bill Reference: [bill_ref]

Customer Name: [cust_name]

BIlling Period: [bill_period]

Bill Amount: [bill_amount]

Admin Fee: [admin_fee]

Bill Total: [total]

Effective Date: [start_dt]

Finish Date: [end_dt]

Branch Office: [br_office]
{/__child_trx_hist_det}

These email notifications are automatically sent by a computerized system and do not require a reply.

For further information, please contact Hello Danamon at 1-500-090 or email hellodanamon@danamon.co.id
For more banking product information visit https://www.danamon.co.id

Thank you for using D-Bank PRO from Bank Danamon, All In One Control.

Best Regards,
PT Bank Danamon Indonesia Tbk
', N'Successful Insurance Payment', N'TC21740_01', NULL, N'BBE3AF48-C33A-4534-8761-6D5FC33035A6', N'2D0F7CF4-710C-453F-9533-B8EF1ABB9184');

INSERT INTO tbl_notification_channel_template VALUES(N'3625E409-531D-4B9E-9138-BD5CB735BF26', 2, N'Successful Insurance Payment', 
N'Dear Valued Customer,

Thank you for using D-Bank PRO. We are pleased to inform you that your payment has been successful.

{__child_trx_hist_det}
Transaction Date: [trans_date]

Reference No.: [ref_no]

Source Account: [acct_num]

Payment: Insurance

Organization : [org_name]

Customer ID: [cust_id]

Bill Reference: [bill_ref]

Customer Name: [cust_name]

BIlling Period: [bill_period]

Bill Amount: [bill_amount]

Admin Fee: [admin_fee]

Bill Total: [total]

Effective Date: [start_dt]

Finish Date: [end_dt]

Branch Office: [br_office]
{/__child_trx_hist_det}

These email notifications are automatically sent by a computerized system and do not require a reply.

For further information, please contact Hello Danamon at 1-500-090 or email hellodanamon@danamon.co.id
For more banking product information visit https://www.danamon.co.id

Thank you for using D-Bank PRO from Bank Danamon, All In One Control.

Best Regards,
PT Bank Danamon Indonesia Tbk
', N'Successful Insurance Payment (No Reply)', N'TC21740_01', NULL, N'BBE3AF48-C33A-4534-8761-6D5FC33035A6', N'3625E409-531D-4B9E-9138-BD5CB735BF26');



--Failed
INSERT INTO tbl_notification_channel_template VALUES(N'C553619A-D481-4233-9855-BCE46A1ABFBD', 1, N'Unsuccessful Insurance Payment', 
N'Dear Valued Customer,

Thank you for using D-Bank PRO. We are sorry to inform you that your payment has been unsuccessful.

{__child_trx_hist_det}
Transaction Date: [trans_date]

Reference No.: [ref_no]

Source Account: [acct_num]

Payment: Insurance

Organization : [org_name]

Customer ID: [cust_id]

Bill Reference: [bill_ref]

Customer Name: [cust_name]

BIlling Period: [bill_period]

Bill Amount: [bill_amount]

Admin Fee: [admin_fee]

Bill Total: [total]

Effective Date: [start_dt]

Finish Date: [end_dt]

Branch Office: [br_office]
{/__child_trx_hist_det}

These email notifications are automatically sent by a computerized system and do not require a reply.

For further information, please contact Hello Danamon at 1-500-090 or email hellodanamon@danamon.co.id
For more banking product information visit https://www.danamon.co.id

Thank you for using D-Bank PRO from Bank Danamon, All In One Control.

Best Regards,
PT Bank Danamon Indonesia Tbk
', N'Unsuccessful Insurance Payment', N'TC21740_02', NULL, N'3CEBB66A-89F7-437D-881D-F4ACB77B427A', N'C553619A-D481-4233-9855-BCE46A1ABFBD');

INSERT INTO tbl_notification_channel_template VALUES(N'48D2822D-EB08-4FD0-BCE7-191EC2F521C7', 2, N'Unsuccessful Insurance Payment', 
N'Dear Valued Customer,

Thank you for using D-Bank PRO. We are sorry to inform you that your payment has been unsuccessful.

{__child_trx_hist_det}
Transaction Date: [trans_date]

Reference No.: [ref_no]

Source Account: [acct_num]

Payment: Insurance

Organization : [org_name]

Customer ID: [cust_id]

Bill Reference: [bill_ref]

Customer Name: [cust_name]

BIlling Period: [bill_period]

Bill Amount: [bill_amount]

Admin Fee: [admin_fee]

Bill Total: [total]

Effective Date: [start_dt]

Finish Date: [end_dt]

Branch Office: [br_office]
{/__child_trx_hist_det}

These email notifications are automatically sent by a computerized system and do not require a reply.

For further information, please contact Hello Danamon at 1-500-090 or email hellodanamon@danamon.co.id
For more banking product information visit https://www.danamon.co.id

Thank you for using D-Bank PRO from Bank Danamon, All In One Control.

Best Regards,
PT Bank Danamon Indonesia Tbk
', N'Unsuccessful Insurance Payment (No Reply)', N'TC21740_02', NULL, N'3CEBB66A-89F7-437D-881D-F4ACB77B427A', N'48D2822D-EB08-4FD0-BCE7-191EC2F521C7');




---Id
--Success
INSERT INTO tbl_res_notification_template VALUES(N'2D0F7CF4-710C-453F-9533-B8EF1ABB9184', N'id', N'Pembayaran Asuransi Berhasil', 
N'Nasabah Yang Terhormat,

Terima kasih telah menggunakan D-Bank PRO. Dengan ini kami informasikan bahwa pembayaran Anda telah berhasil dilakukan.

{__child_trx_hist_det}
Tanggal Transaksi: [trans_date]

No. Referensi: [ref_no]

Sumber Rekening: [acct_num]

Pembayaran: Asuransi

Organisasi : [org_name]

ID Pelanggan:  [cust_id]

Referensi Tagihan: [bill_ref]

Nama Pelanggan: [cust_name]

Periode Tagihan: [bill_period]

Jumlah Tagihan: [bill_amount]

Biaya Admin: [admin_fee]

Total Tagihan: [total]

Tanggal Efektif: [start_dt]

Tanggal Selesai: [end_dt]

Kantor Cabang: [br_office]
{/__child_trx_hist_det}

Notifikasi email dikirim secara otomatis oleh sistem dan tidak memerlukan balasan. 

Informasi lebih lanjut dapat menghubungi Hello Danamon di 1-500-090 atau dapat mengirimkan email ke hellodanamon@danamon.co.id
Untuk informasi produk perbankan lainnya kunjungi https://www.danamon.co.id 

Terima kasih telah menggunakan D-Bank PRO dari Bank Danamon, Semua Dalam Satu Kendali. 

Salam hangat,
PT Bank Danamon Indonesia Tbk
', N'Pembayaran Asuransi Berhasil');

INSERT INTO tbl_res_notification_template VALUES(N'3625E409-531D-4B9E-9138-BD5CB735BF26', N'id', N'Pembayaran Asuransi Berhasil', 
N'Nasabah Yang Terhormat,

Terima kasih telah menggunakan D-Bank PRO. Dengan ini kami informasikan bahwa pembayaran Anda telah berhasil dilakukan.

{__child_trx_hist_det}
Tanggal Transaksi: [trans_date]

No. Referensi: [ref_no]

Sumber Rekening: [acct_num]

Pembayaran: Asuransi

Organisasi : [org_name]

ID Pelanggan:  [cust_id]

Referensi Tagihan: [bill_ref]

Nama Pelanggan: [cust_name]

Periode Tagihan: [bill_period]

Jumlah Tagihan: [bill_amount]

Biaya Admin: [admin_fee]

Total Tagihan: [total]

Tanggal Efektif: [start_dt]

Tanggal Selesai: [end_dt]

Kantor Cabang: [br_office]
{/__child_trx_hist_det}

Notifikasi email dikirim secara otomatis oleh sistem dan tidak memerlukan balasan. 

Informasi lebih lanjut dapat menghubungi Hello Danamon di 1-500-090 atau dapat mengirimkan email ke hellodanamon@danamon.co.id
Untuk informasi produk perbankan lainnya kunjungi https://www.danamon.co.id 

Terima kasih telah menggunakan D-Bank PRO dari Bank Danamon, Semua Dalam Satu Kendali. 

Salam hangat,
PT Bank Danamon Indonesia Tbk
', N'Pembayaran Asuransi Berhasil (Tidak Perlu Dibalas)');



--Failed
INSERT INTO tbl_res_notification_template VALUES(N'C553619A-D481-4233-9855-BCE46A1ABFBD', N'id', N'Pembayaran Asuransi Gagal', 
N'Nasabah Yang Terhormat,

Terima kasih telah menggunakan D-Bank PRO. Dengan ini kami informasikan bahwa pembayaran Anda gagal dilakukan.

{__child_trx_hist_det}
Tanggal Transaksi: [trans_date]

No. Referensi: [ref_no]

Sumber Rekening: [acct_num]

Pembayaran: Asuransi

Organisasi : [org_name]

ID Pelanggan:  [cust_id]

Referensi Tagihan: [bill_ref]

Nama Pelanggan: [cust_name]

Periode Tagihan: [bill_period]

Jumlah Tagihan: [bill_amount]

Biaya Admin: [admin_fee]

Total Tagihan: [total]

Tanggal Efektif: [start_dt]

Tanggal Selesai: [end_dt]

Kantor Cabang: [br_office]
{/__child_trx_hist_det}

Notifikasi email dikirim secara otomatis oleh sistem dan tidak memerlukan balasan. 

Informasi lebih lanjut dapat menghubungi Hello Danamon di 1-500-090 atau dapat mengirimkan email ke hellodanamon@danamon.co.id
Untuk informasi produk perbankan lainnya kunjungi https://www.danamon.co.id 

Terima kasih telah menggunakan D-Bank PRO dari Bank Danamon, Semua Dalam Satu Kendali. 

Salam hangat,
PT Bank Danamon Indonesia Tbk
', N'Pembayaran Asuransi Gagal');

INSERT INTO tbl_res_notification_template VALUES(N'48D2822D-EB08-4FD0-BCE7-191EC2F521C7', N'id', N'Pembayaran Asuransi Gagal', 
N'Nasabah Yang Terhormat,

Terima kasih telah menggunakan D-Bank PRO. Dengan ini kami informasikan bahwa pembayaran Anda gagal dilakukan.

{__child_trx_hist_det}
Tanggal Transaksi: [trans_date]

No. Referensi: [ref_no]

Sumber Rekening: [acct_num]

Pembayaran: Asuransi

Organisasi : [org_name]

ID Pelanggan:  [cust_id]

Referensi Tagihan: [bill_ref]

Nama Pelanggan: [cust_name]

Periode Tagihan: [bill_period]

Jumlah Tagihan: [bill_amount]

Biaya Admin: [admin_fee]

Total Tagihan: [total]

Tanggal Efektif: [start_dt]

Tanggal Selesai: [end_dt]

Kantor Cabang: [br_office]
{/__child_trx_hist_det}

Notifikasi email dikirim secara otomatis oleh sistem dan tidak memerlukan balasan. 

Informasi lebih lanjut dapat menghubungi Hello Danamon di 1-500-090 atau dapat mengirimkan email ke hellodanamon@danamon.co.id
Untuk informasi produk perbankan lainnya kunjungi https://www.danamon.co.id 

Terima kasih telah menggunakan D-Bank PRO dari Bank Danamon, Semua Dalam Satu Kendali. 

Salam hangat,
PT Bank Danamon Indonesia Tbk
', N'Pembayaran Asuransi Gagal (Tidak Perlu Dibalas)');



