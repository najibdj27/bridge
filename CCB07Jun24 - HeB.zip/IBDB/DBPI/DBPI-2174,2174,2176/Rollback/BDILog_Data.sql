USE BDILog
GO


DELETE FROM tbl_trx_log_template WHERE trx_id IN (
'112174001',
'112174002'
)
INSERT INTO tbl_trx_log_template VALUES(N'C5DCC65E-CC9E-436E-AC7B-31AE84CD1986', N'112174001', N'V@#:ref_no;0:Transaction_Date;0:Source_Account;0:Organization;0:Customer_ID;0:Bill_Reference;0:Customer_Name;0:Billing_Period;0:Bill_Amount;0:Admin_Fee;0:Bill_Total;0:Effective_Date;0:Finish_Date;0:Branch_Office;#:reason:optional');
INSERT INTO tbl_trx_log_template VALUES(N'57EDAD61-92D8-406B-A36E-9F130A5C704F', N'112174002', N'V@#:ref_no;0:Transaction_Date;0:Source_Account;0:Organization;0:Customer_ID;0:Bill_Reference;0:Customer_Name;0:Billing_Period;0:Bill_Amount;0:Admin_Fee;0:Bill_Total;0:Effective_Date;0:Finish_Date;0:Branch_Office;#:reason:optional');


