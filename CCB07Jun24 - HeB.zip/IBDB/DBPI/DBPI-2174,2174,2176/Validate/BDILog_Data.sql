USE BDILog
GO


SELECT * FROM tbl_trx_log_template WHERE trx_id IN (
'112174001',
'112174002'
)


