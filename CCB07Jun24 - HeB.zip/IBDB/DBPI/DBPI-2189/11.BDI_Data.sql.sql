USE BDI
GO

delete from tbl_message_detail where message_id in (select id from tbl_message where cd = 'ERR405110077');
delete from tbl_message where cd = 'ERR405110077';
insert into tbl_message (id, cd, message_grp, status_cd, version, variant, last_update_dt) values ('529C8B68-9EBF-4AD4-AF90-CBB851BE6754','ERR405110077','ERROR',113,'529C8B68-9EBF-4AD4-AF90-CBB851BE6754',NULL,NULL);
insert into tbl_message_detail (message_id, message_type, res_cd, message) values ('529C8B68-9EBF-4AD4-AF90-CBB851BE6754','ERROR','en','Your card data is not valid. Please call Hello Danamon 1-500-090 for detail information');
insert into tbl_message_detail (message_id, message_type, res_cd, message) values ('529C8B68-9EBF-4AD4-AF90-CBB851BE6754','ERROR','id','Data kartu Anda tidak valid. Silakan hubungi Hello Danamon 1-500-090 untuk informasi lebih lanjut');
go